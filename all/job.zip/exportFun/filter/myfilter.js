/*
 * @Description: 
 * @version: 
 * @Date: 2019-09-22 23:21:07
 * @LastEditors: yeyifu
 * @LastEditTime: 2019-09-25 21:43:25
 * @Author: yeyifu
 * @LastModifiedBy: yeyifu
 */
exports.myfilter = function (input) {
    return input.slice(5);
};
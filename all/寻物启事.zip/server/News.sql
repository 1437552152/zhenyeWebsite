﻿# Host: 139.224.217.178  (Version 5.7.34)
# Date: 2021-06-14 14:10:23
# Generator: MySQL-Front 6.1  (Build 1.26)


#
# Structure for table "Instructions"
#

CREATE TABLE `Instructions` (
  `id` int(11) DEFAULT NULL,
  `content` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "Instructions"
#

INSERT INTO `Instructions` VALUES (1,'https://mp.weixin.qq.com/s?__biz=MzA4MDkwNzIxMA==&tempkey=MTA0NV9oK2lRTTZDQTBoQXFaMzh2UDZuU0xWT1dyU3ZibDduNlgzTTdNOTN2dnYyRkdpcF9YdVdZNmZZeHdndHZXM0ppcTJBdTBuSHJPSHAwNnBTX3hNZHhOZkpQU0h5ajNEMlV1WUQ3c0FzUDU0NFZocGRvYTFlNWtISURQRGctdlRrdms2NDF2YzdnYm9kcE1mT21rYVd2Z25mM1pESjFiNUZKN0F3Q19Rfn4%3D&chksm=079aed7d30ed646b46a59efb41798bf49fee48cde1e660f8e400079fb8d0f1373919de490cd8#rdhttps://mp.weixin.qq.com/s?__biz=MzA4MDkwNzIxMA==&tempkey=MTA0NV9oK2lRTTZDQTBoQXFaMzh2UDZuU0xWT1dyU3ZibDduNlgzTTdNOTN2dnYyRkdpcF9YdVdZNmZZeHdndHZXM0ppcTJBdTBuSHJPSHAwNnBTX3hNZHhOZkpQU0h5ajNEMlV1WUQ3c0FzUDU0NFZocGRvYTFlNWtISURQRGctdlRrdms2NDF2YzdnYm9kcE1mT21rYVd2Z25mM1pESjFiNUZKN0F3Q19Rfn4%3D&chksm=079aed7d30ed646b46a59efb41798bf49fee48cde1e660f8e400079fb8d0f1373919de490cd8#rdhttps://mp.weixin.qq.com/s?__biz=MzA4MDkwNzIxMA==&tempkey=MTA0NV9oK2lRTTZDQTBoQXFaMzh2UDZuU0xWT1dyU3ZibDduNlgzTTdNOTN2dnYyRkdpcF9YdVdZNmZZeHdndHZXM0ppcTJBdTBuSHJPSHAwNnBTX3hNZHhOZkpQU0h5ajNEMlV1WUQ3c0FzUDU0NFZocGRvYTFlNWtISURQRGctdlRrdms2NDF2YzdnYm9kcE1mT21rYVd2Z25mM1pESjFiNUZKN0F3Q19Rfn4%3D&chksm=079aed7d30ed646b46a59efb41798bf49fee48cde1e660f8e400079fb8d0f1373919de490cd8#rd');

#
# Structure for table "LostAndFound"
#

CREATE TABLE `LostAndFound` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '需求id',
  `userId` varchar(255) DEFAULT NULL COMMENT '需求发布绑定的用户id',
  `name` varchar(255) DEFAULT NULL COMMENT '需求名称',
  `time` varchar(255) DEFAULT NULL COMMENT '创建时间',
  `updateTime` varchar(255) DEFAULT NULL COMMENT '更新时间',
  `userName` varchar(255) DEFAULT NULL COMMENT '创建者姓名',
  `imageUrl` varchar(255) DEFAULT NULL,
  `descc` varchar(255) DEFAULT NULL,
  `content` text,
  `status` varchar(255) DEFAULT NULL COMMENT '1丢失    2.捡到',
  `phone` varchar(255) DEFAULT NULL COMMENT '联系电话',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

#
# Data for table "LostAndFound"
#

INSERT INTO `LostAndFound` VALUES (26,'12','悬赏找包','2021-06-14 13:19',NULL,'高明丽','https://www.qianxunzhe.cn//public/2eafb0f0-585c-4fed-a13e-919c0177a958.jpg','武汉市洪山区','本人于今日2017年8月28日（七夕情人节）中午十二点左右至一点多左右     骑着摩托车路线  ：曹溪121→   美食城  →万宝   →大润发   →财校  至龙门方向   遗失了一个多背带的黄色字母黑包   本人放在助力车踏板上不慎掉了    内有贵重私人物品    。真心找回    希望强大的k友有捡到或者看到  联系本人：18159759096   感谢感谢万分感谢了','1','18133626045'),(27,'12','捡到一个绿色的书包','2021-06-14 13:46',NULL,'高明丽','https://www.qianxunzhe.cn//public/01656f43-d6e4-4881-9dc0-f4ae177bbeef.jpg','阅览室','在五月十四日的晚上，我丢失了一个绿色的书包在阅览室。内有两本英语书，一个铅笔盒，一个MP3播放器，自行车的钥匙。此刻我很担心。拾到者请还给李霞的三年级一班，十分感激!','2','15559885652');

#
# Structure for table "userInfo"
#

CREATE TABLE `userInfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(255) DEFAULT NULL COMMENT '账号',
  `pwd` varchar(255) DEFAULT NULL COMMENT '密码',
  `name` varchar(255) DEFAULT NULL COMMENT '姓名',
  `remark` varchar(255) DEFAULT NULL COMMENT '自我描述',
  `email` varchar(255) DEFAULT NULL COMMENT '邮箱',
  `content` text,
  `headpic` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

#
# Data for table "userInfo"
#

INSERT INTO `userInfo` VALUES (11,'18133626045','123456','212',NULL,'21212','23232323121221212','https://www.qianxunzhe.cn//public/ae1e5853-105b-4003-96da-fc8b77e19b54.png'),(20,'18133626046','123456',NULL,NULL,NULL,NULL,NULL);

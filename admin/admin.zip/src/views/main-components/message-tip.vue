<!--
 * @Description: 
 * @Author: yfye
 * @Date: 2019-08-20 00:29:22
 * @LastEditTime: 2021-04-11 16:45:48
 * @LastEditors: yfye
-->
<template>
	<div class="message-con">
		<!-- 	11111 -->
	</div>
</template>

<script>


export default {
	name: "messageTip",
	data() {
		return {
			value: 0,
			backlogArr: [],
			backlogData: {}
		}
	},
  methods: {
	
	},
	
};
</script>

<style lang="less" scoped>
	.ivu-dropdown-rel{
		a{
			color: rgb(73,80,96);
		}
	}
	.ivu-dropdown-item{
		.ivu-row{
			width: 190px;
		}
	}
</style>


<!--
 * @Description: 
 * @version: 
 * @Date: 2019-07-31 19:53:23
 * @LastEditors: yfye
 * @LastEditTime: 2021-04-25 23:33:15
 * @Author: yeyifu
 * @LastModifiedBy: yeyifu
 -->
<style lang="less">
@import "./login.less";
</style>

<template>
	<div class="login" @keydown.enter="handle">
		<div class="login-con">
			<Card :bordered="false">
				<p slot="title">
					<Icon type="log-in"></Icon> 欢迎注册
				</p>
				<div class="form-con">
					<Form ref="form" :model="form" :rules="rules">
						<FormItem prop="username">
							<Input v-model="form.username" :disabled="btnDisable" placeholder="请输入手机号">
								<span slot="prepend">
									<Icon :size="16" type="person"></Icon>
								</span>
							</Input>
						</FormItem>

						<FormItem prop="password">
							<Input type="password" v-model="form.password" :disabled="btnDisable" placeholder="请输入密码">
								<span slot="prepend">
									<Icon :size="14" type="locked"></Icon>
								</span>
							</Input>
						</FormItem>

                        <FormItem prop="webname">
							<Input  v-model="form.webname" :disabled="btnDisable" placeholder="请输入公司名称">
								<span slot="prepend">
									<Icon :size="14" type="clock"></Icon>
								</span>
							</Input>
						</FormItem>

                        <FormItem prop="legalPerson">
							<Input v-model="form.legalPerson" :disabled="btnDisable" placeholder="请输入公司法人">
								<span slot="prepend">
									<Icon :size="14" type="chatbubble-working"></Icon>
								</span>
							</Input>
						</FormItem>
                        <FormItem prop="webAddress">
							<Input v-model="form.webAddress" :disabled="btnDisable" placeholder="请输入公司地址">
								<span slot="prepend">
									<Icon :size="14" type="calculator"></Icon>
								</span>
							</Input>
						</FormItem>
						<FormItem style="margin-top:10px">
							<Button @click="handle('form')" type="primary" long>确定</Button>
						</FormItem>
						 <div>已注册？请在这里<span style="color:rgb(60, 106, 233);cursor:pointer;" @click="hreftwo">登录</span>。
            </div>
					</Form>
				</div>
			</Card>
		</div>
	</div>
</template>
<script>
import { Register } from '@/service/getData';

export default {
    name: 'register',
    data () {
       
        const validatePwsd = (rule, value, callback) => {
            if (!value) {
                callback(new Error('请输入密码'));
            } else {
                let len = value.length;
                if (len >= 6 && len <= 8) {
                    callback();
                } else {
                    callback(new Error('请输入6~8位密码'));
                }
            }
        };

        const validateMobile=(rule, value, callback) => {
            if (!value) {
                callback(new Error('请输入手机号'));
            } else {
                 var re = /^1\d{10}$/
                if (re.test(value)) {
                    callback();
                } else {
                   callback(new Error('请输入合法的手机号'));
                }           
            }
        };

        return {
            btnDisable: false,
            form: {
                username: null,
                password: null,
                webname:null,
                legalPerson:null,
                webAddress:null
            },
            messshow: false,
            errormessage: null,
            rules: {
                username: [{ validator: validateMobile, required: true, trigger: 'blur', message: '不能为空'  }],
                password: [{ validator: validatePwsd, required: true, trigger: 'blur', message: '不能为空' }],
            },
            permissions: {}
        };
    },
    methods: {
        handle (name) {
            this.$refs[name].validate((valid) => {
                if (valid) {
                    Register({webAddress:this.form.webAddress, username: this.form.username, password: this.form.password,webname: this.form.webname, legalPerson: this.form.legalPerson})
                        .then(res => {
                            if (res.status == '200') {
                                this.$Message.success(res.msg);
                                setTimeout(() => {
                                    this.$router.push({path: '/login'}); 
                                }, 3000);
                               
                            } else {
                                this.$Message.error(res.msg);
                            }
                        })
                        .catch(err => {
                        });
                }
            });
        },
        hreftwo () {
            this.$router.push({ path: '/login' });
        }
    },
    created () {}
};
</script>